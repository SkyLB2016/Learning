package cn.enjoyedu.generic.defgeneric;

/**
 * @author Mark老师   享学课堂 https://enjoy.ke.qq.com
 * 往期课程咨询芊芊老师  QQ：2130753077 VIP课程咨询 依娜老师  QQ：2133576719
 * 类说明：
 */
public class ImplGenertor2 implements Genertor<String> {
    @Override
    public String next() {
        return null;
    }
}
