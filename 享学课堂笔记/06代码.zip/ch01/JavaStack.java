package com.xiangxue.ch01;


/**
 * 享学课堂——虚拟机栈
 * 栈异常！调用方法(king)的次数()：19038 (默认情况下)
 * 异常！调用方法(king)的次数()：16672
 */
public class JavaStack {
/*    public static class User{
        public int id = 0;
        public String name = "";
    }*/
    //常量
    final  String Fs ="常在河边走，哪有不湿鞋";
    //静态变量
    static String Ss ="以静制动";
    //次数
    int count =0 ;
    //King老师出差
    public void king(int money){
        //13号妓师
        Object tech13 = new Object();
        //调用一次13号服务
        tech13.hashCode();
        int i;
        money = money -100; //花费100
        count++;
        //if(count ==2000) return;
        king(money);
     }
    public static void main(String[] args)throws Throwable {
        JavaStack javaStack = new JavaStack();
        try {
            javaStack.king(10000);
        }catch (Throwable e){
            //输出异常时循环的次数
            System.out.println("栈异常！调用方法(king)的次数()："+javaStack.count);
            throw e;
        }
    }

}
